--HANDS ON PRACTICE
-- ALL RAN CORRECTLY
CREATE TABLE store_reps
(rep_ID NUMBER(5),
 last VARCHAR2(15),
 first VARCHAR2(10),
 comm CHAR(1));
 
 
ALTER TABLE store_reps 
	MODIFY (CONSTRAINT store_reps_rep_id_pk PRIMARY KEY(rep_ID),
	comm CHAR(1) DEFAULT 'Y');
	
ALTER TABLE store_reps
	MODIFY (last CONSTRAINT store_reps_last_nn NOT NULL,
	first CONSTRAINT store_reps_first_nn NOT NULL); 
 
 ALTER TABLE store_reps
	ADD (base_salary NUMBER(7,2),
	CONSTRAINT base_salary_ok CHECK (base_salary>0));
 
 -- ADVANCED CHALLENGE
  -- DID NOT RUN (INVALID IDENTIFIERS)
  -- Slides 34/35 Module 7
 CREATE TABLE project -- total of 13 constraints
	(proj# NUMBER(5),
	p_name VARCHAR2(15),
	p_desc VARCHAR2(30),
	p_budget NUMBER(3),
	CONSTRAINT project_proj#_pk PRIMARY KEY(proj#),
	CONSTRAINT project_p_name_uk UNIQUE(p_name) CONSTRAINT project_p_name_nn NOT NULL,
	p_desc CONSTRAINT project_p_desc_nn NOT NULL,
	p_budget CONSTRAINT project_p_budget_nn NOT NULL);
	
CREATE TABLE project -- total of 3 constraints
	(proj# NUMBER(5),
	p_name VARCHAR2(15) NOT NULL,
	p_desc VARCHAR2(30)NOT NULL,
	p_budget NUMBER(3) NOT NULL,
	CONSTRAINT project_proj#_pk PRIMARY KEY(proj#),
	CONSTRAINT project_p_name_uk UNIQUE(p_name));
	
CREATE TABLE workorders
	(wo# NUMBER(5),
	wo_desc VARCHAR2(30) NOT NULL,
	wo_assigned VARCHAR2(15) NOT NULL,
	wo_hours NUMBER (5) NOT NULL,
	wo_start DATE,
	wo_due DATE,
	wo_complete VARCHAR(1),
	CONSTRAINT workorders_wo#_pk PRIMARY KEY(wo#),
	CONSTRAINT workorders_proj#_fk FOREIGN KEY(proj#) REFERENCES project(proj#),
	CONSTRAINT workorders_wo_desc_uk UNIQUE(wo_desc),
	wo_assigned CONSTRAINT workorders_wo_assigned_nn,
	CONSTRAINT workorders_wo_hours_ok CHECK(wo_hours>0),
	CONSTRAINT workorders_wo_complete_ok CHECK(wo_complete=='Y'||wo_complete=='N'));