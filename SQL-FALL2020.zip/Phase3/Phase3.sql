--QUERY #1
--average odometer reading of all customers from a zip 
SELECT AVG(ODOMETERREADING) 
	FROM REPAIRORDER JOIN VEHICLE USING(VIN)
	JOIN CUSTOMER USING (CUSTOMER#)
	WHERE ADDRESS LIKE '%61761'; -- ends with 61761
	--Note: In phase 2 we only included an address as one value so we adapted by searching for the address to END WITH the desired zip

--QUERY #2
--List the number of vehicles by vehicle make (e.g., Toyota 3, BMW 2). 
--Sort your results by number of vehicles in the descending order then by vehicle make in the alphabetic order.
SELECT MODEL, COUNT(MODEL) 
    FROM VEHICLE
    GROUP BY MODEL
    ORDER BY COUNT(MODEL) DESC, MODEL ASC;

--QUERY #3
-- Calculate the total values of the part inventory at each branch. 
SELECT  BRANCHID, SUM(PARTCOST*QTYONHAND) "TOTAL"
	FROM INVENTORY JOIN PART USING (PART#)
    GROUP BY BRANCHID;

--QUERY #4
--How many repair orders during the first ten months of this year have involved the use of part name XYZ? 
--(Choose any part name that is already in your PART table.)
SELECT COUNT (REPAIRORDER#) 
	FROM REPAIR r JOIN  REPAIRORDER ro USING (REPAIRORDER#)
    JOIN PART p USING (PART#)
	WHERE p.PARTNAME= 'tire' AND ro.RDATE BETWEEN '1-JAN-20' AND '31-OCT-20';

--QUERY #5
--Display the number of repairs each vehicle received in 2019. 
--(Exclude vehicles that did not receive any repairs in 2019.)  
--Sort results by the number of repairs in the descending order.
SELECT COUNT (REPAIRORDER#)
	FROM REPAIRORDER
	WHERE RDATE BETWEEN '1-JAN-19' AND '31-DEC-19'
	ORDER BY REPAIRORDER# DESC;

	
--BONUS QUERY
--A repair order may require multiple parts. 
--Display the repair order in 2019 with the highest total value in parts?
SELECT MAX(PARTCOST * QTYUSED) "Highest Total"
	FROM PART JOIN REPAIR USING (PART#)
    JOIN REPAIRORDER USING (REPAIRORDER#)
	WHERE RDATE BETWEEN '1-JAN-19' AND '31-DEC-19';
	
