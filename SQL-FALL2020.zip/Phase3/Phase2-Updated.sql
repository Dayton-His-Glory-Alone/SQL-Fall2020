-- Phase 2
CREATE TABLE CUSTOMER 
(customer# NUMBER(3) NOT NULL,
name VARCHAR2(30) NOT NULL,
address VARCHAR2(40),
phone NUMBER(9),
CONSTRAINT Customer_Customer#_pk  PRIMARY KEY(customer#));

CREATE TABLE VEHICLE
(vin NUMBER(6) NOT NULL, 
customer# NUMBER(3) NOT NULL,
vYear NUMBER(4),
model VARCHAR2(15),
plate# VARCHAR2(9) NOT NULL,
vState VARCHAR2(15),
CONSTRAINT vehicle_vin_pk  PRIMARY KEY(vin),
CONSTRAINT vehicle_customer#_fk FOREIGN KEY(customer#) REFERENCES CUSTOMER(customer#));

CREATE TABLE REPAIRORDER
(repairOrder# NUMBER(6) NOT NULL,
vin NUMBER(6) NOT NULL,
rDate DATE,
odometerReading NUMBER(6),
CONSTRAINT repairOrder_repairOrder#_pk  PRIMARY KEY(repairOrder#),
CONSTRAINT repairOrder_vin_fk FOREIGN KEY(vin) REFERENCES VEHICLE(vin));

CREATE TABLE REPAIR
(repairOrder# NUMBER(6) NOT NULL,
part# NUMBER(5) NOT NULL,
qtyUsed NUMBER(2),
CONSTRAINT repair_repairOrder#part#_pk PRIMARY KEY(repairOrder#, part#));

CREATE TABLE PART
(part# NUMBER(5) NOT NULL,
partName VARCHAR2(20) NOT NULL,
partCost NUMBER(6) NOT NULL,
partSize VARCHAR2(20),
CONSTRAINT part_part#_pk PRIMARY KEY(part#));

CREATE TABLE INVENTORY
(part# NUMBER(5) NOT NULL,
branchID VARCHAR2(20) NOT NULL,
qtyOnHand NUMBER(2),
CONSTRAINT inventory_part#branchID_pk PRIMARY KEY (part#,branchID));

CREATE TABLE BRANCH
(branchID VARCHAR2(4) NOT NULL,
CONSTRAINT branch_branchID_pk PRIMARY KEY (branchID));

-- Populate table
INSERT INTO CUSTOMER(customer#,name,address,phone)
VALUES(189,'Elliott','1600 Penn 61761',309573334);
INSERT INTO VEHICLE(vin,customer#,vYear,model,plate#,vState)
VALUES(123456,189,1999,'Juke','091 V2830','ILLINOIS');
INSERT INTO REPAIRORDER(repairOrder#,vin,rDate,odometerReading)
VALUES(54629,123456,'09-JUN-2012',160000);
INSERT INTO REPAIR(repairOrder#,part#,qtyUsed)
VALUES(54629,18763,10);
INSERT INTO PART(part#,partName,partCost,partSize)
VALUES(18763,'muffler',45,'large');
INSERT INTO INVENTORY(part#,branchID,qtyOnHand)
VALUES(18763,'B123',23);
INSERT INTO BRANCH(branchID)
VALUES('B123');

INSERT INTO CUSTOMER(customer#,name,address,phone)
VALUES(00000002,'Dayton','728 Dale St. Normal IL, 61761',929233335);
INSERT INTO VEHICLE(vin,customer#,vYear,model,plate#,vState)
VALUES(654321,00000002,2011,'Spyder','FAS V2830','ILLINOIS');
INSERT INTO REPAIRORDER(repairOrder#,vin,rDate,odometerReading)
VALUES(74629,654321,'12-MAY-2020',90000);
INSERT INTO REPAIR(repairOrder#,part#,qtyUsed)
VALUES(74629,54321,10);
INSERT INTO PART(part#,partName,partCost,partSize)
VALUES(54321,'tire',200,'medium');
INSERT INTO INVENTORY(part#,branchID,qtyOnHand)
VALUES(54321,'B124',36);
INSERT INTO BRANCH(branchID)
VALUES('B124');

INSERT INTO CUSTOMER(customer#,name,address,phone)
VALUES(00000003,'Bob','808 Hale St. Normal WA, 61761',829233336);
INSERT INTO VEHICLE(vin,customer#,vYear,model,plate#,vState)
VALUES(874390,00000003,1997,'Accord','SLO V2900','WASHINGTON');
INSERT INTO REPAIRORDER(repairOrder#,vin,rDate,odometerReading)
VALUES(47629,874390,'20-JAN-1998',200000);
INSERT INTO REPAIR(repairOrder#,part#,qtyUsed)
VALUES(47629,76321,8);
INSERT INTO PART(part#,partName,partCost,partSize)
VALUES(76321,'brake pad',50,'small');
INSERT INTO INVENTORY(part#,branchID,qtyOnHand)
VALUES(76321,'B125',5);
INSERT INTO BRANCH(branchID)
VALUES('B125');

INSERT INTO CUSTOMER(customer#,name,address,phone)
VALUES(00000004,'Jimmy','828 Hale St. Normal IL, 61761',403233336);
INSERT INTO VEHICLE(vin,customer#,vYear,model,plate#,vState)
VALUES(874390,00000004,2019,'Accord','SLO V2900','ILLINOIS');
INSERT INTO REPAIRORDER(repairOrder#,vin,rDate,odometerReading)
VALUES(57629,874390,'20-JAN-2020',200000);
INSERT INTO REPAIR(repairOrder#,part#,qtyUsed)
VALUES(57629,00321,8);
INSERT INTO PART(part#,partName,partCost,partSize)
VALUES(00321,'brake pad',50,'small');
INSERT INTO INVENTORY(part#,branchID,qtyOnHand)
VALUES(00321,'B126',5);
INSERT INTO BRANCH(branchID)
VALUES('B126');

INSERT INTO CUSTOMER(customer#,name,address,phone)
VALUES(00000005,'Jimmy','828 Hale St. Normal IL, 61761',403233336);
INSERT INTO VEHICLE(vin,customer#,vYear,model,plate#,vState)
VALUES(000390,00000005,2020,'Sonata','GLO V2900','ILLINOIS');
INSERT INTO REPAIRORDER(repairOrder#,vin,rDate,odometerReading)
VALUES(57629,000390,'30-DEC-2019',200000);
INSERT INTO REPAIR(repairOrder#,part#,qtyUsed)
VALUES(57629,00021,8);
INSERT INTO PART(part#,partName,partCost,partSize)
VALUES(00021,'brake pad',50,'small');
INSERT INTO INVENTORY(part#,branchID,qtyOnHand)
VALUES(00021,'B127',5);
INSERT INTO BRANCH(branchID)
VALUES('B127');
