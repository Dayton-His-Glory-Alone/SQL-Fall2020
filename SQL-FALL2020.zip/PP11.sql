-- Hands on Assignment

--Display a list of all data contained in the BOOKS table.
SELECT * 
	FROM BOOKS; 
-- Create a list containing the publisher’s name, the person usually contacted, 
--and the publisher’s phone number. Rename the contact column “Contact Person” in the displayed results. (Hint: use the PUBLISHER table.)
SELECT name, contact as "Contact Person", phone 
	FROM PUBLISHER;
 
--List the customer number from the ORDERS table for each customer who has placed an order with the bookstore. List each customer number only once
SELECT UNIQUE customer# 
	FROM ORDERS;

-- Advanced Challenge
--1
SELECT UNIQUE lastname||', '||firstname "name", address, city||', '|| state "Location", zip 
	FROM CUSTOMERS;

--2
SELECT UNIQUE title "Title", ((retail-cost)/cost)*100 "Profit %" 
	FROM BOOKS;
