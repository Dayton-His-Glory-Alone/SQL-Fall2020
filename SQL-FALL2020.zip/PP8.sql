-- hands on practice
CREATE TABLE EMPLOYEES 
(EmployeeID NUMBER(5), 
Lname VARCHAR2(10), 
Fname VARCHAR2(10),
JobClass VARCHAR2(4)); 
 
 
ALTER TABLE EMPLOYEES
ADD(EmpDate VARCHAR2(10),
EndDate VARCHAR2(10));


ALTER TABLE EMPLOYEES
MODIFY (JobClass VARCHAR2(2));

TRUNCATE TABLE  EMPLOYEES;

DROP TABLE EMPLOYEES;
FLASHBACK TABLE EMPLOYEES
TO BEFORE DROP;

DROP TABLE EMPLOYEES PURGE;

--advanced challenge
ALTER TABLE ACCTMANAGER -- Add two new columns
ADD (Comm_id NUMBER(3,0) DEFAULT 10, --MODIFY only integers
Ben_id NUMBER(3,0));
-- set Comm_id to 10 automatically when no value given